<?= $this->extend('admin/layout/link') ?>
<?= $this->section('auth') ?>
<div class="container-fluid py-5">
    <div class="container py-5">
    <h2 class="mb-5" style="text-align: center; color: #d4a762; font-family: 'Times New Roman', Times, serif; font-size: 50px; font-weight: bold;"><span>Detail Pembayaran</span></h2>

        
        
        <form action="<?= route_to('transaksitambahstore') ?>" method="post" enctype="multipart/form-data">
            <div class="row g-4" >
                <div class="col-md-10 col-lg-6 col-xl-5 " >
                    <div class="form-item">
                        <label class="form-label my-3">Nama<sup>*</sup></label>
                        <input type="text" class="form-control" value="<?= session('nama_pelanggan') ?>" name="nama_pelanggan">
                    </div>
                    <div class="form-item">
                        <label class="form-label my-3">Alamat Lengkap <sup>*</sup></label>
                        <input type="text" class="form-control" value="<?= session('alamat') ?>" name="alamat">
                    </div>
                    <div class="form-item">
                        <label class="form-label my-3">Nomor Hp<sup>*</sup></label>
                        <input type="text" class="form-control" value="<?= session('nomor_telepon') ?>" name="nomor_telepon">
                    </div>
                    <div class="form-item">
                        <label class="form-label my-3">Alamat Email<sup>*</sup></label>
                        <input type="email" class="form-control" value="<?= session('email') ?>" name="email">
                    </div>
                    <br>
                    <div class="form-item">
                        <textarea name="catatan" class="form-control" spellcheck="false" cols="30" rows="11" placeholder="Catatan Pesanan (Opsional)"></textarea>
                    </div>
                </div>
                <div class="col-md-12 col-lg-6 col-xl-7">
                    <div class="table-responsive" >
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Produk</th>
                                    <th scope="col">Menu</th>
                                    <th scope="col">Harga</th>
                                    <th scope="col">Jumlah Pembelian</th>
                                    <th scope="col">Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!empty($dataToRecord)) : ?>
                                    <?php foreach ($dataToRecord as $record) : ?>
                                        <!-- Product Row -->
                                        <tr class="product-row">
                                            <th scope="row">
                                                <div class="d-flex align-items-center">
                                                    <img src="<?= base_url('public/produk/img/' . $record['foto']); ?>" alt="Product Image" class="flex-shrink-0" style="max-width:125px;">
                                                </div>
                                            </th>
                                            <td>
                                                <p class="mb-0 mt-4"><?= $record['nama_produk'] ?></p>
                                            </td>
                                            <td class="price">
                                                <p class="mb-0 mt-4"><?= 'Rp ' . number_format($record['harga'], 0, ",", "."); ?></p>
                                            </td>
                                            <td>
                                                <div class="input-group quantity mt-4" style="width: 100px;">
                                                    <p class="form-control form-control-sm text-center border-0 quantity-input"><?= $record['jumlah_pembelian'] ?></p>
                                                </div>
                                            </td>
                                            <td class="total">
                                                <p class="mb-0 mt-4"><?= 'Rp ' . number_format($record['total'], 0, ",", "."); ?></p>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                        <div class="subtotal-section">
    <h4 class="mt-4" style="font-weight: bold;">TOTAL : <span id="subtotal"><?= 'Rp ' . number_format(array_sum(array_column($dataToRecord, 'total')), 0, ",", "."); ?></span></h4>
</div>

                    </div>
                </div>
            </div>
            <div class="row g-4 text-center align-items-center justify-content-center pt-4">
                <button type="submit" class="btn border-white py-3 px-4 text-uppercase w-100 text bold"style="background-color: #d4a762; border-color: #d4a762; color: white;" ><span>Buat
                    Pesanan</span></button>
            </div>
        </form>
    </div>
</div>
<?= $this->endSection() ?>